# BEM VINDO 🖕

# SSH-PLUS

# @ALAN-SSH

*PROJETO EM ANDAMENTO...


# Modo de instalação
# 👇👽👍
Só joga na máquina e deixar instalar

• atualiza sistema

• desativa Ipv6

• instala recursos e o script
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/upalfadate/hdisbsi/main/ssh-plus)

```
